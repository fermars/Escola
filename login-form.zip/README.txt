A Pen created at CodePen.io. You can find this one at http://codepen.io/umeshagouda/pen/afcjG.

 Modern login form using less and css3. its easy to use in your project..