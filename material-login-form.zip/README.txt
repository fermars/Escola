A Pen created at CodePen.io. You can find this one at http://codepen.io/andytran/pen/RPBdgM.

 Interactive Material Design Login Form.

This could be a lot more smoother, which is why I'll be updating it sometime this week when I have free time. However, here's the first version of it.
-- 
Close button should function properly now.

Design by Boris Borisov @ MaterialUp
http://www.materialup.com/posts/compact-login